package Lab8.prob4;

import java.util.Arrays;
import java.util.List;

public class Words {
    public static final
    List<String> listWords =
            Arrays.asList("cook","crowd","hello","chaos","dock","crop");
}
